﻿using System;
using System.Collections.Generic;
using System.Text;
using Sys = Cosmos.System;

namespace ProOS
{
    public class Kernel : Sys.Kernel
    {

        protected override void BeforeRun()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("ProOS Loaded!");
        }

        protected override void Run()
        {
            Console.Write("ProOS >> ");
            var input = Console.ReadLine();
            switch (input)
            {

                default:
                    Console.WriteLine(input + ": Unknow Command");
                    break;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                case "Help":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Here are all the commands:");
                    Console.WriteLine("Help;");
                    Console.WriteLine("Cls;");
                    Console.WriteLine("Random;");
                    Console.WriteLine("Calc;");
                    Console.WriteLine("Off;");
                    Console.WriteLine("And About.");
                    break;
                case "Random":
                    byte[] bytes1 = new byte[5];
                    Random rnd1 = new Random();
                    rnd1.NextBytes(bytes1);
                    for (int ctr = bytes1.GetLowerBound(0);
                         ctr <= bytes1.GetUpperBound(0);
                         ctr++)
                    {
                        Console.Write("{0, 5}", bytes1[ctr]);
                        if ((ctr + 1) % 10 == 0) Console.WriteLine();
                    }
                    break;
                case "Cls":
                    Console.Clear();
                    break;
                case "About":
                    Console.WriteLine("Creaters: xeos1k and minecraftkingyt Testers: minecraftkingyt xeos1k Create in Cosmos C# and Assembler");
                    break;
                case "Calc":
                    int num1;
                    int num2;
                    int result;

                    string answer;

                    Console.WriteLine("Hello, welcome to the calculator program!");
                    Console.WriteLine("Please enter your first number.");

                    num1 = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Please enter your second number.");

                    num2 = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("What type of operation would you like to do?");
                    Console.WriteLine("Please enter pl this +, mi this -, mu this *, ohter key is /.");

                    answer = Console.ReadLine();

                    if (answer == "pl")
                    {
                        result = num1 + num2;
                    }
                    else if (answer == "mi")
                    {
                        result = num1 - num2;
                    }
                    else if (answer == "mu")
                    {
                        result = num1 * num2;
                    }
                    else
                    {
                        result = num1 / num2;
                    }

                    Console.WriteLine("The result is " + result);

                    Console.WriteLine("Thank you for using the calculator program!");

                    Console.ReadKey();
                    break;
            }
        }
    }
}
